# 1.1.0

## Removed the following mods

- MultiUserChest - User would revieve a bug when two users tried to access the same item in a chest at the same time.

## Added the following mods

- AzuWearNTearPatches
- AzuWorkbenchTweaks
- OdinCampsite
- SleepSkip
- Xportal
- HoneyPlus
